# =====================================================================
# CATEGORY 5: REAL-WORLD SCENARIO-BASED CODING QUESTIONS
# Easy topics: simple calculators, basic input validation
# Medium topics: booking/inventory logic, basic simulations,
#                data validation with multiple conditions
# =====================================================================

# ---------------------------------------------------------------------
# EASY 1: BMI calculator with input validation
# ---------------------------------------------------------------------
def bmi_calculator(weight_kg, height_m):
    if weight_kg <= 0 or height_m <= 0:
        return "Invalid input: weight and height must be positive"

    bmi = weight_kg / (height_m * height_m)

    if bmi < 18.5:
        category = "Underweight"
    elif bmi < 25:
        category = "Normal"
    elif bmi < 30:
        category = "Overweight"
    else:
        category = "Obese"

    return round(bmi, 2), category

print(bmi_calculator(70, 1.75))  # (22.86, 'Normal')
print(bmi_calculator(-5, 1.75))  # Invalid input...


# ---------------------------------------------------------------------
# EASY 2: Simple interest calculator with validation
# ---------------------------------------------------------------------
def simple_interest_calculator(principal, rate, years):
    if principal < 0 or rate < 0 or years < 0:
        return "Invalid input: values cannot be negative"

    interest = (principal * rate * years) / 100
    total_amount = principal + interest
    return interest, total_amount

print(simple_interest_calculator(1000, 5, 2))  # (100.0, 1100.0)


# ---------------------------------------------------------------------
# EASY 3: Simple calculator (four operations + validation)
# ---------------------------------------------------------------------
def simple_calculator(a, b, operator):
    if operator == "+":
        return a + b
    elif operator == "-":
        return a - b
    elif operator == "*":
        return a * b
    elif operator == "/":
        if b == 0:
            return "Error: division by zero"
        return a / b
    else:
        return "Error: unknown operator"

print(simple_calculator(10, 5, "/"))   # 2.0
print(simple_calculator(10, 0, "/"))   # Error: division by zero


# =====================================================================
# MEDIUM SECTION
# =====================================================================

# ---------------------------------------------------------------------
# MEDIUM 1: Seat booking system (simple simulation)
# Why: "simple booking/inventory logic" on the syllabus
# ---------------------------------------------------------------------
class SeatBooking:
    def __init__(self, total_seats):
        self.total_seats = total_seats
        # True = available, False = booked
        self.seats = [True] * total_seats

    def book_seat(self, seat_number):
        # seat_number is 1-indexed for user friendliness
        if seat_number < 1 or seat_number > self.total_seats:
            return "Invalid seat number"
        index = seat_number - 1
        if not self.seats[index]:
            return "Seat already booked"
        self.seats[index] = False
        return "Seat " + str(seat_number) + " booked successfully"

    def cancel_seat(self, seat_number):
        if seat_number < 1 or seat_number > self.total_seats:
            return "Invalid seat number"
        index = seat_number - 1
        if self.seats[index]:
            return "Seat was not booked"
        self.seats[index] = True
        return "Seat " + str(seat_number) + " cancelled"

    def available_seats(self):
        count = 0
        for seat in self.seats:
            if seat:
                count += 1
        return count

bus = SeatBooking(5)
print(bus.book_seat(2))        # Seat 2 booked successfully
print(bus.book_seat(2))        # Seat already booked
print(bus.available_seats())   # 4
print(bus.cancel_seat(2))      # Seat 2 cancelled


# ---------------------------------------------------------------------
# MEDIUM 2: Inventory stock management simulation
# Why: "basic simulations" + "data validation with multiple conditions"
# ---------------------------------------------------------------------
class Inventory:
    def __init__(self):
        self.stock = {}  # item_name -> quantity

    def add_stock(self, item, quantity):
        if quantity <= 0:
            return "Quantity must be positive"
        if item in self.stock:
            self.stock[item] += quantity
        else:
            self.stock[item] = quantity
        return item + " stock updated to " + str(self.stock[item])

    def sell_item(self, item, quantity):
        if item not in self.stock:
            return "Item not found"
        if quantity <= 0:
            return "Quantity must be positive"
        if self.stock[item] < quantity:
            return "Not enough stock. Only " + str(self.stock[item]) + " left"
        self.stock[item] -= quantity
        return "Sold " + str(quantity) + " " + item + "(s)"

    def low_stock_report(self, threshold=5):
        low_items = []
        for item, qty in self.stock.items():
            if qty < threshold:
                low_items.append(item)
        return low_items

inv = Inventory()
print(inv.add_stock("Notebook", 10))
print(inv.sell_item("Notebook", 7))
print(inv.sell_item("Notebook", 5))   # Not enough stock
print(inv.low_stock_report())         # ['Notebook']


# ---------------------------------------------------------------------
# MEDIUM 3: Loan eligibility checker - multi-condition data validation
# Why: exact "data validation with multiple conditions" topic
# ---------------------------------------------------------------------
def loan_eligibility(age, monthly_income, credit_score, existing_loans):
    if age < 18 or age > 65:
        return "Not eligible: age out of range"
    if monthly_income < 20000:
        return "Not eligible: income too low"
    if credit_score < 600:
        return "Not eligible: credit score too low"
    if existing_loans >= 3:
        return "Not eligible: too many existing loans"

    # all checks passed - now decide the loan tier
    if credit_score >= 750 and monthly_income >= 50000:
        return "Eligible: Premium tier"
    else:
        return "Eligible: Standard tier"

print(loan_eligibility(30, 60000, 780, 1))  # Eligible: Premium tier
print(loan_eligibility(17, 60000, 780, 1))  # Not eligible: age out of range
print(loan_eligibility(30, 15000, 780, 1))  # Not eligible: income too low
