# =====================================================================
# CATEGORY 3: ALGORITHMIC PROBLEM-SOLVING TASKS
# Easy topics: linear search, basic sorting (bubble/selection), traversal
# Medium topics: two-pointer, sliding window, prefix sums, greedy,
#                binary search
#
# No sorted(), no min()/max() where the point IS the algorithm,
# no bisect module - everything hand-rolled.
# =====================================================================

# ---------------------------------------------------------------------
# EASY 1: Linear search
# ---------------------------------------------------------------------
def linear_search(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i  # found at this index
    return -1  # not found

print(linear_search([4, 2, 7, 1, 9], 7))  # 2
print(linear_search([4, 2, 7, 1, 9], 5))  # -1


# ---------------------------------------------------------------------
# EASY 2: Bubble sort
# ---------------------------------------------------------------------
def bubble_sort(arr):
    arr = arr.copy()  # don't mutate the caller's list
    n = len(arr)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:
            break  # already sorted, stop early
    return arr

print(bubble_sort([5, 1, 4, 2, 8]))  # [1, 2, 4, 5, 8]


# ---------------------------------------------------------------------
# EASY 3: Selection sort
# ---------------------------------------------------------------------
def selection_sort(arr):
    arr = arr.copy()
    n = len(arr)
    for i in range(n):
        smallest_index = i
        for j in range(i + 1, n):
            if arr[j] < arr[smallest_index]:
                smallest_index = j
        arr[i], arr[smallest_index] = arr[smallest_index], arr[i]
    return arr

print(selection_sort([64, 25, 12, 22, 11]))  # [11, 12, 22, 25, 64]


# ---------------------------------------------------------------------
# EASY 4: Find max and min manually (no max()/min())
# ---------------------------------------------------------------------
def find_max_min(arr):
    biggest = arr[0]
    smallest = arr[0]
    for num in arr[1:]:
        if num > biggest:
            biggest = num
        if num < smallest:
            smallest = num
    return biggest, smallest

print(find_max_min([3, 7, 1, 9, 4]))  # (9, 1)


# =====================================================================
# MEDIUM SECTION
# =====================================================================

# ---------------------------------------------------------------------
# MEDIUM 1: Two-pointer - find a pair that sums to target (sorted array)
# Why: exact "two-pointer technique" topic on syllabus
# ---------------------------------------------------------------------
def two_sum_sorted(arr, target):
    left = 0
    right = len(arr) - 1
    while left < right:
        current_sum = arr[left] + arr[right]
        if current_sum == target:
            return (left, right)
        elif current_sum < target:
            left += 1   # need a bigger sum, move left pointer up
        else:
            right -= 1  # need a smaller sum, move right pointer down
    return None

print(two_sum_sorted([1, 2, 3, 4, 6], 6))  # (1, 3) -> 2+4=6


# ---------------------------------------------------------------------
# MEDIUM 2: Sliding window - max sum of subarray of size k
# Why: exact "sliding window" topic on syllabus
# ---------------------------------------------------------------------
def max_sum_subarray(arr, k):
    if len(arr) < k:
        return None

    window_sum = 0
    for i in range(k):
        window_sum += arr[i]

    max_sum = window_sum
    for i in range(k, len(arr)):
        # slide the window: drop the leftmost, add the new right element
        window_sum = window_sum - arr[i - k] + arr[i]
        if window_sum > max_sum:
            max_sum = window_sum
    return max_sum

print(max_sum_subarray([2, 1, 5, 1, 3, 2], 3))  # 9 (5+1+3)


# ---------------------------------------------------------------------
# MEDIUM 3: Prefix sums - answer range sum queries fast
# Why: exact "prefix sums" topic on syllabus
# ---------------------------------------------------------------------
def build_prefix_sum(arr):
    prefix = [0] * (len(arr) + 1)
    for i in range(len(arr)):
        prefix[i + 1] = prefix[i] + arr[i]
    return prefix

def range_sum(prefix, left, right):
    # inclusive range [left, right], 0-indexed on the original array
    return prefix[right + 1] - prefix[left]

arr = [1, 2, 3, 4, 5]
prefix = build_prefix_sum(arr)
print(range_sum(prefix, 1, 3))  # 2+3+4 = 9


# ---------------------------------------------------------------------
# MEDIUM 4: Binary search (iterative, manual)
# Why: exact "binary search" topic on syllabus
# ---------------------------------------------------------------------
def binary_search(arr, target):
    low = 0
    high = len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1

print(binary_search([1, 3, 5, 7, 9, 11], 7))  # 3


# ---------------------------------------------------------------------
# MEDIUM 5: Greedy - activity/meeting selection (max non-overlapping)
# Why: "basic greedy approach" topic on syllabus
# ---------------------------------------------------------------------
def max_non_overlapping_activities(activities):
    # activities: list of (start, end) tuples
    # manual sort by end time (insertion sort, since sorted() is off-limits)
    activities = activities.copy()
    for i in range(1, len(activities)):
        key = activities[i]
        j = i - 1
        while j >= 0 and activities[j][1] > key[1]:
            activities[j + 1] = activities[j]
            j -= 1
        activities[j + 1] = key

    count = 0
    last_end_time = -1
    for start, end in activities:
        if start >= last_end_time:
            count += 1
            last_end_time = end
    return count

acts = [(1, 3), (2, 4), (3, 5), (0, 6), (5, 7), (8, 9)]
print(max_non_overlapping_activities(acts))  # 3  -> e.g. (1,3),(3,5),(5,7) or (1,3),(5,7),(8,9)
