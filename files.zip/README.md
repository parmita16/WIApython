# She-Codes Prep — Full Practice Set

Mapped directly to your syllabus. 5 files, ~30 problems total, all in
plain Python, **no shortcut built-ins** (`math.gcd`, `math.comb`,
`sorted()`, `max()/min()` where that's literally the problem, `bisect`,
etc. are avoided or hand-rolled) so you're safe if the real HackerRank
environment restricts them.

| File | Syllabus Category | Problems |
|---|---|---|
| `01_basic_programming/practice.py` | Basic Programming (Easy 1 / Hard 1) | even-odd, mult. table, digit sum, grade calc + transpose, number pyramid, spiral traversal, matrix multiply |
| `02_math_logical/practice.py` | Math & Logical Reasoning (Medium 1 / Hard 1) | manual sqrt+geometry, prime check, nCr from scratch, AP/GP series + manual GCD/LCM, modular exponentiation, sequence-type detector, dice probability |
| `03_algorithmic/practice.py` | Algorithmic Problem-Solving (Easy 1 / Medium 1) | linear search, bubble sort, selection sort, manual max/min + two-pointer, sliding window, prefix sums, binary search, greedy activity selection |
| `04_debugging/practice.py` | Debugging (Easy 1) | 6 buggy→fixed pairs: off-by-one, missing return, index error, syntax errors, wrong operator, infinite loop |
| `05_realworld/practice.py` | Real-World Scenarios (Easy 1 / Medium 1) | BMI calc, interest calc, 4-op calculator + seat booking, inventory system, loan eligibility checker |

## How to use this for max score, given the scoring rules

Since **partial credit is per test case** (not all-or-nothing), your
priority order should be:

1. **Get every Easy question 100% correct first** — they're worth less
   per question (9 marks) but are the fastest guaranteed points, and a
   silly bug here costs you disproportionately relative to effort.
2. **On Hard questions, aim to pass *some* test cases even if you can't
   finish** — 3/5 test cases on a Hard question (27/46) beats spending
   all your time and scoring 0. Don't go for "perfect or nothing."
3. **The +1 full-solve bonus on Hard only triggers on all 5 test cases**
   — so once you're close to a full solve on a Hard question, it's
   worth the extra few minutes to chase it; partial progress there
   doesn't get you the bonus.
4. **Test edge cases yourself before submitting**: n=0, negative
   numbers, empty arrays, single-element arrays — these are exactly
   what hidden test cases target and where off-by-one/edge bugs hide.

## Duo strategy (from the syllabus's own tip)

- Assign one person to **read + plan out loud**, the other to **type**,
  and swap after each question — this matches the syllabus's explicit
  suggestion and keeps both of you fast on both roles.
- Since Challenge 1 (Easy, 60 min for 4 Qs) is time-tight, decide in
  advance who owns which 2 of the 4 Easy questions so you're working in
  parallel instead of serially.

## Practice next

Run each file (`python3 01_basic_programming/practice.py` etc.) and try
changing the test inputs to unusual edge cases (0, negative numbers,
empty lists, huge numbers) to build the instinct for what hidden test
cases will probe.
