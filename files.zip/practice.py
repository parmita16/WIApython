# =====================================================================
# CATEGORY 1: BASIC PROGRAMMING CHALLENGES
# Easy topics: variables/data types, input/output, if-else, basic loops
# Hard topics: multi-dim arrays, loops+functions+conditionals combined,
#              pattern printing with logic
# =====================================================================

# ---------------------------------------------------------------------
# EASY 1: Even or Odd checker
# Why: classic if-else + input parsing warm-up
# ---------------------------------------------------------------------
def is_even_odd(n):
    # using modulo, the core "remainder" trick every syllabus expects
    if n % 2 == 0:
        return "Even"
    else:
        return "Odd"

print(is_even_odd(7))   # Odd
print(is_even_odd(10))  # Even


# ---------------------------------------------------------------------
# EASY 2: Multiplication table using a basic for loop
# Why: loop + string formatting, very common "easy" opener question
# ---------------------------------------------------------------------
def multiplication_table(n, upto=10):
    lines = []
    for i in range(1, upto + 1):
        # building the string manually instead of using f-string shortcuts
        # everywhere, so the logic is crystal clear
        lines.append(str(n) + " x " + str(i) + " = " + str(n * i))
    return lines

for line in multiplication_table(5):
    print(line)


# ---------------------------------------------------------------------
# EASY 3: Sum of digits of a number
# Why: while loop + modulo/floor division, appears constantly
# ---------------------------------------------------------------------
def sum_of_digits(n):
    n = abs(n)  # handle negative numbers safely
    total = 0
    while n > 0:
        digit = n % 10       # pluck off the last digit
        total = total + digit
        n = n // 10          # chop off the last digit
    return total

print(sum_of_digits(1234))  # 10
print(sum_of_digits(0))     # 0


# ---------------------------------------------------------------------
# EASY 4: Grade calculator (if-elif-else chain)
# Why: real "basic programming" style, tests input validation too
# ---------------------------------------------------------------------
def grade_calculator(score):
    if score < 0 or score > 100:
        return "Invalid score"
    elif score >= 90:
        return "A"
    elif score >= 75:
        return "B"
    elif score >= 60:
        return "C"
    elif score >= 40:
        return "D"
    else:
        return "F"

print(grade_calculator(85))   # B
print(grade_calculator(105))  # Invalid score


# =====================================================================
# HARD SECTION
# =====================================================================

# ---------------------------------------------------------------------
# HARD 1: Transpose a matrix manually (no numpy, no zip() shortcut)
# Why: multi-dimensional array manipulation from scratch
# ---------------------------------------------------------------------
def transpose(matrix):
    rows = len(matrix)
    cols = len(matrix[0])
    # build an empty cols x rows matrix first
    result = []
    for i in range(cols):
        new_row = []
        for j in range(rows):
            new_row.append(0)
        result.append(new_row)

    # now fill it in: result[j][i] = matrix[i][j]
    for i in range(rows):
        for j in range(cols):
            result[j][i] = matrix[i][j]
    return result

m = [[1, 2, 3],
     [4, 5, 6]]
for row in transpose(m):
    print(row)
# [1, 4]
# [2, 5]
# [3, 6]


# ---------------------------------------------------------------------
# HARD 2: Pattern printing with logic (numbered pyramid)
# Why: nested loops + conditionals, exactly what "pattern printing
#      with logic" means on the syllabus
# ---------------------------------------------------------------------
def number_pyramid(n):
    lines = []
    for i in range(1, n + 1):
        spaces = " " * (n - i)   # left padding shrinks each row
        numbers = ""
        for num in range(1, i + 1):
            numbers += str(num)
        line = spaces + numbers
        lines.append(line)
    return lines

for line in number_pyramid(5):
    print(line)
# 1
#  12
#   123
#    1234
#     12345
# (note: printed largest->smallest indent order above, adjust range if
#  you want the pyramid growing top to bottom visually)


# ---------------------------------------------------------------------
# HARD 3: Spiral traversal of a 2D array
# Why: classic "multi-dimensional array + combined logic" hard question
# ---------------------------------------------------------------------
def spiral_traverse(matrix):
    result = []
    top, bottom = 0, len(matrix) - 1
    left, right = 0, len(matrix[0]) - 1

    while top <= bottom and left <= right:
        # go right along the top row
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1

        # go down along the right column
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1

        if top <= bottom:
            # go left along the bottom row
            for col in range(right, left - 1, -1):
                result.append(matrix[bottom][col])
            bottom -= 1

        if left <= right:
            # go up along the left column
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][left])
            left += 1

    return result

m2 = [[1, 2, 3],
      [4, 5, 6],
      [7, 8, 9]]
print(spiral_traverse(m2))  # [1, 2, 3, 6, 9, 8, 7, 4, 5]


# ---------------------------------------------------------------------
# HARD 4: Matrix multiplication done manually
# Why: combines loops + functions + conditionals (dimension checking)
# ---------------------------------------------------------------------
def matrix_multiply(a, b):
    rows_a, cols_a = len(a), len(a[0])
    rows_b, cols_b = len(b), len(b[0])

    if cols_a != rows_b:
        return None  # can't multiply, dimensions don't match

    result = []
    for i in range(rows_a):
        result_row = []
        for j in range(cols_b):
            total = 0
            for k in range(cols_a):
                total += a[i][k] * b[k][j]
            result_row.append(total)
        result.append(result_row)
    return result

a = [[1, 2], [3, 4]]
b = [[5, 6], [7, 8]]
print(matrix_multiply(a, b))  # [[19, 22], [43, 50]]
